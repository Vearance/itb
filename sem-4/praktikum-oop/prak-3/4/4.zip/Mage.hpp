#pragma once
#include <iostream>
#include <string>
#include "Character.hpp"
using namespace std;

class Mage : virtual public Character {
protected:
    int mana;

public:
    Mage(string characterId, string name, int hp, int level,
            int mana);
    virtual ~Mage();
    void castSpell() const;
    int getMana() const;

};
