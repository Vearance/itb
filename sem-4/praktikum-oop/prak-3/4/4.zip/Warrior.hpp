#pragma once
#include <iostream>
#include <string>
#include "Character.hpp"
using namespace std;

class Warrior : virtual public Character {
protected:
    int strength;

public:
    Warrior(string characterId, string name, int hp, int level, int strength);
    virtual ~Warrior();
    void attack() const;
    int getStrength() const;

};
